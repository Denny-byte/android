package com.example.tour;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final String [] cabs={"http://www.uber.com","http://www.bolt.eu/en-ke/cities/nairobi/","http://www.little.bz","http://www.delightcabs.co.ke","http://www.absolutecabs.co.ke","http://www.pewin.co.ke","info@jimcab.co.ke","http://www.kenatco.co.ke","http://www.universalcabs.co.ke","http://www.aircab.co.ke","http://www.princesstravelskenya.com"};

        ListAdapter myAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,cabs);
        final ListView myList=(ListView)findViewById(R.id.mylist);

        myList.setAdapter(myAdapter);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

//                Toast.makeText(MainActivity.this, ""+parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,web.class);
                String x=parent.getItemAtPosition(position).toString();
                intent.putExtra("transfered",x);
                startActivity(intent);

            }
        });


    }
}
